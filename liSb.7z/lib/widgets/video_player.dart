
import 'dart:html' as html;
import 'dart:ui' as ui;
import 'package:flutter/cupertino.dart';

import '../styles/styles.dart';

class VideoPlayerWidget extends StatefulWidget {
  String url;
  String name;
  VideoPlayerWidget({Key? key, required this.url, required this.name})
      : super(key: key);

  @override
  State<VideoPlayerWidget> createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget> {
  final html.ImageElement img = html.ImageElement();

  late Widget imgWidget;




  @override
  void initState() {
    super.initState();

    // img.height = 500;
    // img.width = 500;
    img.src = widget.url;
    img.style.border = 'none';

    // ui.platformViewRegistry.registerViewFactory(
    //     'img',
    //         (int viewId) => ImageElement()
    //       ..width = 1280
    //       ..height = 720
    //       ..src = 'http://127.0.0.1:5000/video_feed'
    //       ..style.border = 'none');

    ui.platformViewRegistry.registerViewFactory('img', (int viewId) {
      return img;
    });

    imgWidget = HtmlElementView(
      key: UniqueKey(),
      viewType: 'img',
    );
  }


  Widget build(BuildContext context) {
    return Center(child:
        AspectRatio(

            // width: 1280,
            // height: 720,
            aspectRatio: 16/9,
            child: imgWidget));
  }
}
