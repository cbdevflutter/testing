import 'package:flutter/material.dart';

class PieData {
  final double value;
  final Color color;

  PieData({required this.value, required this.color});
}
