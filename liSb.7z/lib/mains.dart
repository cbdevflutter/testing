import 'dart:html' as html;

import 'package:flutter/material.dart';
import 'dart:ui' as ui;

void main() {

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'MJPEG demo'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({required this.title}) : super();

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final html.ImageElement img = html.ImageElement();
  late Widget imgWidget;


  @override
  void initState() {
    super.initState();

    img.height = 500;
    img.width = 500;
    img.src = 'http://127.0.0.1:5000/video_feed';
    img.style.border = 'none';

    // ui.platformViewRegistry.registerViewFactory(
    //     'img',
    //         (int viewId) => ImageElement()
    //       ..width = 1280
    //       ..height = 720
    //       ..src = 'http://127.0.0.1:5000/video_feed'
    //       ..style.border = 'none');

    ui.platformViewRegistry.registerViewFactory('img', (int viewId) {
      return img;
    });

    imgWidget = HtmlElementView(
      key: UniqueKey(),
      viewType: 'img',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("sdfdsf"),
        ),
        // body: Center(child: Image.network('http://127.0.0.1:5000/video_feed',),));
        body: Center(child:
        Container(
            width: 320,
            height: 240,
            child: imgWidget),));
  }
}