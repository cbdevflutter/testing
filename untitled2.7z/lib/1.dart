import 'package:flutter/material.dart';
import 'package:video_box/video.controller.dart';
import 'package:video_box/video_box.dart';
import 'package:video_player/video_player.dart';

class ListVideo extends StatefulWidget {
  @override
  _ListVideoState createState() => _ListVideoState();
}

class _ListVideoState extends State<ListVideo> {
  List<VideoController> vcs = [];

  @override
  void initState() {
    super.initState();
    for (var i = 0; i < 4; i++) {
      vcs.add(VideoController(source: VideoPlayerController.network('http://127.0.0.1:5000/video_feed'))
        ..initialize());
    }
  }

  @override
  void dispose() {
    for (var vc in vcs) {
      vc.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('list video'),
      ),
      body: ListView(
        children: <Widget>[
          for (var vc in vcs)
            Padding(
              padding: const EdgeInsets.only(top: 12.0),
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: VideoBox(controller: vc),
              ),
            ),
        ],
      ),
    );
  }
}








class _MyHomePageState extends State<MyHomePage> {
  late VideoPlayerController videoPlayerController;
  late CustomVideoPlayerController _customVideoPlayerController;

  String videoUrl =
      "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4";

  @override
  void initState() {
    super.initState();
    videoPlayerController = VideoPlayerController.network(videoUrl)
      ..initialize().then((value) => setState(() {}));
    _customVideoPlayerController = CustomVideoPlayerController(
      context: context,
      videoPlayerController: videoPlayerController,
    );
  }

  @override
  void dispose() {
    _customVideoPlayerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      navigationBar: CupertinoNavigationBar(
        middle: Text(widget.title),
      ),
      child: SafeArea(
        child: CustomVideoPlayer(
            customVideoPlayerController: _customVideoPlayerController
        ),
      ),
    );
  }
}

Image.network(
"http:127.0.0.1:5000/video_feed",
fit: BoxFit.contain,
errorBuilder: (context, error, stackTrace) {
print("----------- Error: $error");
return Text("ERROR", style: TextStyle(color: Colors.red));
},
loadingBuilder: (context, child, loadingProgress) {
print("----------- Loading: ${loadingProgress?.cumulativeBytesLoaded}/${loadingProgress?.expectedTotalBytes}");
return child;
},
frameBuilder: (context, child, frame, wasSynchronouslyLoaded) {
print("----------- frame: $frame, $wasSynchronouslyLoaded");
return child;
}
),
ElevatedButton(
onPressed: connect,
child: const Text("Connect"),

),
ElevatedButton(
onPressed: disconnect,
child: const Text("Disconnect"),
),
],
),
const SizedBox(
height: 50.0,
),
// _isConnected
//     ? StreamBuilder(
//   stream: _channel!.stream,
//   builder: (context, snapshot) {
//     if (!snapshot.hasData) {
//       return const CircularProgressIndicator();
//     }
//
//     if (snapshot.connectionState == ConnectionState.done) {
//       return const Center(
//         child: Text("Connection Closed !"),
//       );
//     }
//     //? Working for single frames
//     return Image.memory(
//       Uint8List.fromList(
//         base64Decode(
//           (snapshot.data.toString()),
//         ),
//       ),
//       gaplessPlayback: true,
//
//     );